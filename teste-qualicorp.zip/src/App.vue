
<template>
  <div>

    <lista-quali-corp />

  </div>
</template>

<script>
import ListaQualiCorp from './components/ListaQualiCorp.vue'
export default {
  name: 'App',
  components: {
    ListaQualiCorp
  }
}
</script>
